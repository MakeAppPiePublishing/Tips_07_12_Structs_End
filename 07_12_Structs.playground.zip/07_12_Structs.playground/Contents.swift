import UIKit

class PizzaClass{
    var size:Int
    var topping:String
    init(size:Int,topping:String){
        self.size = size
        self.topping = topping
    }
    func printPizza(){
        print("\(size) inch Pizza with \(topping)")
    }
}

struct PizzaStruct{
    var size:Int
    var topping:String
    init(topping:String){
        self.size = 10
        self.topping = topping
    }
    func printPizza(){
        print("\(size) inch Pizza with \(topping)")
    }
}

var pizzaStruct = PizzaStruct( topping: "Pepperoni")
let pizzaClass = PizzaClass(size: 10, topping: "BBQ Chicken")

pizzaStruct.printPizza()
pizzaClass.printPizza()

pizzaStruct.topping = "Olives"
pizzaClass.topping = "Sausage"

pizzaStruct.printPizza()
pizzaClass.printPizza()

var struct2 = pizzaStruct
struct2.size = 14
let class2 = pizzaClass
class2.size = 14

struct2.printPizza()
class2.printPizza()

pizzaStruct.printPizza()
pizzaClass.printPizza()
